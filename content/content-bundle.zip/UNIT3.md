
## IEEE 802.11.ah 
- 802.11.ah
- also called Low-Power Wi-Fi specifies 
- a throughput up to 4 Mbit/s
- ISM frequency band of 900 MHz
- wide range of IoT applications while being able to provide more energy efficiency, QoS, scalability (a large number of devices) and cost-effective solutions

### NFC 