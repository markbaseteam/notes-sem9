food pyramid
![[../imgs/Pasted image 20230825234939.png]] 
- food should have nutrients that our bodies r not able to produce at all or in sufficient quantity 

### Carbohydrates
- Carbohydrates are sugar molecules or chain of sugar molecules that form a complex structure example starch or fiber i.e. cellulose
- containes 3 elements C,H and O
- Sources fruit, bread , grain , sugar etc.
- 
- Glucose a simple sugar molecule , is the main source of energy in our body
- brain has a very high metabolisum thus uses high amount of glucose ~5.6 milligram glucose per 100 gram of brain tissue per minute.thus is there is insuffecient abount of glucose the brain might not function properly

- uses of Carbo hydrates
1. Providing continuous energy and regulation of blood glucose
    
2. Sparing the use of proteins    
	1. glucose is synthesized from amino acids
3. Energy storage
    
4. Building Macromolecules
	1. carbo are essential building blocks of important macromolecules, such as RNA, DNA, and ATP

types

- Monosaccharides - single molicule
- Disaccharides -2 molecule
- Polysaccharide - multiple (long chain)
- Dietary Fiber - cellulose special

glycemic index
-  hepls us under stand how much the food boosts the blood sugar
- ![](https://lh3.googleusercontent.com/K-htZNWigQs9fg4ZW7LI0JkaLZsJ5URPWHrWaPEqBNW9fAmocL3VTPfcUS0zC9PevgPnju0KPQL9rFnY4ou9mOOisCvb-xM9tHZ4FxJCSDW8FgHyQHS-3wpLRhxNNZNGcVq4BvfA4-F-ltVTPR1z5g=s2048)
- high gi is bad suggeted to limit it
- ![Glycemic Index and Glycemic Load | TarlaDalal.com](https://lh3.googleusercontent.com/m7HxYM8q53nGQGP4YmiGRsbGmzsiklrOjBmZW-hrfzU_xEQlU_An3kWdufB1E_x0wk05_Vv8uw__-r6R7rGMk_alD-SQC7RQ9YMRcH8plybdHm67F2FIS6xI16y8ptRLMZOF7wx-z2UxzF7DkwEnfA=s2048)
- ![Hypoglycemia (Low Blood Sugar): Symptoms & Treatment](https://lh3.googleusercontent.com/Vod3q9ARj3h8O5WVH-I3dX_DkHZy8lazwX8Yb31fG78f0vjqrtgd4QmBgi7rjvj0PuaJAeKR1d0d4SsgX_ILL7gwMH54nJgcg3-2Dt6nawpJ1u250cVTxWuLmck8KlaIUzzGKV54jhIJ5VsfqJU6-A=s2048)
- not enough carbs causes ketosis , in which body starts to use fat as its source of energy
- ![ketosis vs ketoacidosis symptoms](https://lh5.googleusercontent.com/5omvUSY1gDR9qhyReN5je_IFJ-mEon_Kcu4gF-345dslMEXGGsvAKmVxM3MaANGstBVj1-0sCiQHru3sMwHByZAeLwKLUxOCaCJ_HUC19G2OrVNbRgnwH_9AMSVrZ3GhKOyuhkHpqiiZ16BJO9ND6A=s2048)![keto diet macros](https://lh3.googleusercontent.com/NfR0ik5l4J7FcRtoO4LOURlgptUbOhbcuelqiaWILesWP1VbfpEShmll-Kili3mAJndAj7V0ENRTzCXriDIqMzWJP-zjJjTbchq_U6Fkn1hqXz-23YnAMSgV-9BdtdjoM-PbRR8dqO6n7LD2e8tOIw=s2048)


good carb and bad carb
- carbs form natural sources is good and helps with metabolism and carbs from processed foods i.e. glucose (simple sugar)and or starch are bad carbs. excess amount of these have variety of consequences
Simple carbs are digested quickly, causing spikes in blood sugar and making you feel hungry sooner
  
complex carbs or good carbs
They are often packed with nutritional layers like bran and fiber that make you [digest them](https://www.webmd.com/digestive-disorders/good-digestion) ​[slower](https://www.webmd.com/digestive-disorders/good-digestion). ​

### Protein
- Proteins are large biomolecules and macromolecules that comprise one or more long chains of amino acid residues that are peptide-bonded.
- ![](https://lh5.googleusercontent.com/cZF_qsESLzmAeU1zzHtNeyCrwm7KxAxDc1OyjB6RBWB4URjIINRr4bR1In7Fxy8SnIAm966LL8kpEjOGySzeTPvtvU-To9OyG03LUnMmN-mCbG0EqeoRBsIvnHQ7-IOBz8f9M6GpjBGyM3BYd2BpBw=s2048)
- Protein is found throughout the body—in muscle, bone, skin, hair, and virtually every other body part or tissue.
- 10 to 35 percent of our daily calories should come from lean protein sources such as low-fat meat, dairy, beans or eggs.
- The average person needs about **7 grams** of protein every day for every **20 pounds** of body weight
- Protein is the major structural component of cells and is responsible for the building and repair of body tissues.
- Nine of the 20 amino acids, known as essential amino acids, must be provided in the diet as they cannot be synthesized in the body

Functions
- Structural Proteins:-
	- Some proteins form supporting structures, e.g., elastin of ligaments, collagen of tendons, cartilages, bone and connective tissue.
	- Keratin is the major constituent of external protective structure of animals like hair, feathers, layer of skin, nails, claws, hoofs etc.
- Enzymes:- 
	- Many proteins function as enzymes to catalyze biochemical reactions that occur in the living world. Enzymes play a key role in the metabolism.
	- Every enzyme is specific in action. E.g., Amylase, protease, RUBISCO etc. 
	- Amylase is necessary for breaking down the bonds in starches, polysaccharides, and complex carbohydrates into simpler simple sugars.
- Carrier Proteins:
	- A carrier protein is a membrane protein which bind and transport specific molecules across a membrane or in a body fluid.
	- Haemoglobin of RBCs transports oxygen in the body. RBCs contain haemoglobin (Hb) which is made up of 4 polypeptide chains and contains an iron ion. Iron has strong affinity for oxygen. In lungs, oxygen combines with haemoglobin to produce oxyhaemoglobin. In body cell, oxygen is released and is able to diffuse into body cell.
- Receptor Proteins:
	- A number of proteins present on the external surface of cell membrane act as receptor molecules. 
	- A receptor protein molecule receives chemical signals from outside a cell. When such chemical signals bind to a receptor, they cause some form of cellular/tissue response. 
	- For example, insulin receptor protein:
	- when insulin is released in blood, the receptor proteins present on cell membrane binds with this insulin. This binding changes the permeability of cell membrane and glucose can enter the cell through glucose channels.
- Hormones
	- Some hormones are proteinaceous, e.g., insulin
- Contractile Proteins: 
	- Actin and myosin are two protein molecules in muscles and are mainly involved in muscle contraction in humans and animals.
- Defensive proteins: 
	- Some proteins act as antibodies (immunoglobulins) that participate in the defence mechanism of the body.
- Storage Proteins: 
	- Storage proteins serve as biological reserves of metal ions and amino acids, used by organisms.  These occur in milk, eggs and seeds to nourish the young ones. 

	Eg. They include casein of milk, albumin of egg white and glutelin in cereals.


sources

Animal-based foods (meat, poultry, fish, eggs, and dairy foods) tend to be good sources of complete protein, while plant-based foods (fruits, vegetables, grains, nuts, and seeds) often lack one or more essential amino acid. Those who abstain from eating animal-based foods can eat a variety of protein-containing plant foods each day in order to get all the amino acids needed to make new protein, and also choose to incorporate complete plant proteins


lack of protein
- Lack of protein can make you lose muscle mass, which in turn cuts your strength, makes it harder to keep your balance, and slows your metabolism.
- Serious protein deficiency can cause swelling, fatty liver, skin degeneration, increase the severity of infections and stunt growth in children.
- However, too much protein — especially with no fat or carbs — can be harmful. This is something to be aware of considering the prevalence of many high-protein diets.
- Protein poisoning is when the body takes in too much protein with not enough fat and carbohydrate for a long period of time.
- it can put the body at risk for increased levels of ammonia, urea, and amino acids in the blood. Although very rare, protein poisoning can be fatal because of these increased levels.
- ![](https://lh5.googleusercontent.com/N3VlDLnBOPLCBfP_sBaKWbcWxm9u5FvB27dKLWSJERpdHnWPY1eKcBtCusAbpluAaproCp10SMnnuaN1RMxJTDkPmfAKzO9dnaNYg9yGm-pAdeht9AAoCnR4IbstoY4S4f6qMPRzFoMmq4POIvpKpQ=s2048)


### Lipids
- Dietary lipids are primarily oils (liquid) and fats (solid).  
- It is an energy source and  when consumed, increases the absorption of fat-soluble vitamins including vitamins A, D, E and K.
- They are also vital part of cell membrane. 20 to 35 percent of your daily intake should come from fat.
- lipids similarly to sugar is made of C , H and o
- 2 types 
	-  saturated lipid, single covalent bond between carbon and hydrogen. This makes them solid at room temperature. They are found in Red meat, poultry, Whole-milk dairy products like milk, cheese, and ice cream, Butter, Eggs, Palm and coconut oil.
	- In unsaturated lipid, double bond between carbon  and hydrogen. These fats are liquid at room temperature. They come mainly from vegetables, nuts, and fish.(not good)
	- Trans fats are unsaturated fats they are bad for body as they increase low density cholesterol causing damage to arteries
- Fatty acids
	- Fatty acids are the simplest monomer unit (eg. stearic acid, palmitic acid).  They can be saturated or unsaturated
	- A group of fatty acids called the essential fatty acids (EFAs) is important for human health. However, they cannot be synthesized by the human body and must be obtained from foods or supplements.
	- The more important EFAs are omega-3 fatty acids, omega-6 fatty acids and cis-fatty acids
	- Types of EFA
		1.  Triglyceride (fats and oils) 
		2. Phospholipids: It is a major lipid component of cell membranes. 
		3. Sphingolipids: Major component of cell membranes 
		4. Steroids: These are compounds that have four rings of carbon atoms.  
		5. Waxes: They are esters of long-chain fatty acids and long-chain alcohols.
	- good sources include flax seeds , tofu , salmon ,chia seeds.

### Functions
1. Energy Storage 
2. Insulating and Protecting :  Lipids help insulate and protect our organs by forming a layer of adipose tissue around them. This layer helps to regulate body temperature and provides cushioning. For example: The layer of fat under the skin helps keep our bodies warm in cold temperatures
3. Regulating and Signalling:
4. Transporting(fat soluble subtences for absorbtion)


low fat
![Fat Deficiency May Lead to Other Disorders](https://lh3.googleusercontent.com/1gg313ip6wJ_RtH4LBsQdywf2FHsXgalP3B0H18eqvCJw9YdQCjZLqgXV7AVkPDyKs1z5rYkyPCO1BYnN4wMb3C6sptK3Md6AKK9y-8okYVTDaQAhYUzIvSxzAPreKQ-B-xhsXtc-dyv7gONlBCEaA=s2048)
![IJMS | Free Full-Text | Lipids and Lipid-Processing Pathways in Drug  Delivery and Therapeutics](https://lh5.googleusercontent.com/NABKQsYRLlkiYP84zG4-5FsRQ68oIJxPRer3rqAWNN51HH0OiageyGR7rNSnxJUEA0OU17Yuf0q9OvrMQlkwBNBh1jFHGy-CEiNX2mS5h_v7ddpSMRgN-H4NvUqQnMqQCAwSO-6Ay0tVUjerWJv8xw=s2048)

exces fat
- Leads to Obesity because more than required calories are consumed. In addition, the excess carbohydrates are also converted to fat for storage in the body resulting in obesity. 
- Slows down the digestion and absorption of foods. 
- Interferes with the absorption of calcium by combining with calcium to form an insoluble calcium soap. 
- Cause ketosis unless adequate carbohydrate is present to complete the oxidation of fat.
- - Choose healthy options such as omega-3-rich foods like fish, walnuts and vegetable-based oils. Omega-3s help with development and growth. 
    
- Limit intake of saturated fats such as high-fat meats and full-fat dairy. Other smart choices include nuts, seeds and avocado.