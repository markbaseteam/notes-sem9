# NB-iot
- NB-IoT (Narrow Band Internet of Things) is a low-cost, low- power, wide-area cellular connectivity for the Internet of Things 
- NB-IoT is developed by 3GPP (3rd Generation Partnership Project) to enable a wide range of cellular devices and services 
- The 3GPP Rel-13, published in June 2016, introduces NB-IoT. This system, based on Long Term Evolution (LTE) technology, supports most LTE functionalities, although with essential simplifications to reduce device complexity.  
- The design objectives of NB-IoT include low complexity devices, high coverage, long device battery life, and massive capacity. 
- Latency is relaxed although a delay budget of 10 seconds is the target for exception reports .

# LTE / LTE-A
- LTE (Long-Term Evolution) is a standard wireless communication for high-speed data transfer between mobile phones based on GSM/UMTS network technologies 
- It can cover fast travelling devices and provide multicasting and broadcasting services. LTE-A (LTE Advanced) is an improved version of LTE, including bandwidth extension, which supports
	- up to 100 MHz,
	- downlink and uplink spatial multiplexing, 
	- extended coverage, 
	- higher throughput 
	- lower latencies. 
- LTE-A encompasses a set of cellular communication protocols that fit well for Machine-Type Communications (MTC) and IoT infrastructures, especially for smart cities where long term durability of infrastructure is expected .
- At the physical layer, LTE-A uses orthogonal frequency division multiple access (OFDMA) by which the channel bandwidth is partitioned into smaller bands called physical resource blocks (PR B).

# LoRa/LoRaWAN

- LoRa (Long Range) is a long-range wireless communications system, promoted by the LoRa Alliance. 
- This system aims at being used in long-lived battery-powered devices, where the energy consumption is of paramount importance [32]. 
- LoRa refers to two distinct layers:
	- A physical layer using the Chirp Spread Spectrum (CSS) [33] radio modulation technique
	- A MAC layer protocol LoRaWAN (Long Range Wide-Area Network) [34].
- The LoRa physical layer, developed by Semtech, allows for long-range, low-power and low-throughput communications
- it operates at 433mhz
- the payload of each transition can range from 2 - 225 octates
- data rate up to 50kbps when channel aggregation is applied
- the LoRa modulation is proprietary technology by semtech
![](../imgs/Pasted%20image%2020231004231344.png)

![](../imgs/Pasted%20image%2020231004231931.png)
