# NFC
NFC (Near Field Communication) is based on the ISO/IEC standard and this technology is created on the RFID to enable a short-range communication (no more than some centimeters). 
While NFC uses similar technology principles in RFID, it is not only used for identification but also for more elaborate two-way communication
Each NFC tag has a unique identifier and can contain small amount of data. 
This tag can be read only (similar to RFID tags for identification purposes) or can be changed later by the device 
There are three main operating modes for NFC: 
- card emulation mode (passive mode),
- reader/writer mode (active mode) 
- peer-to peer mode. 
NFC technology is extensively used in mobile phones, industrial applications and contactless payment systems. In the same way, NFC makes it easier to connect, commission, and control IoT devices in different environments like home, factory and the work.