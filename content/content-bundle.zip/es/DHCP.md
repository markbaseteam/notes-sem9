Dynamic Host configuration Protocol

standrd defied by RFC 1541

this service usualy running in homw wifi routers distribute ip addresses and other configuration information to clients 
the basic info shared is :-
- ip add
- subnet mask
- default gateway 
and can optionaly also assign a dns(domain name server)

there are 4 types of dhcp packets
- DHCPDISCOVER
- DHCPOFFER
- DHCPREQUEST
- DHCPACK